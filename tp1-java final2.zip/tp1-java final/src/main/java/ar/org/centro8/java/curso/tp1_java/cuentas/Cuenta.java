package ar.org.centro8.java.curso.tp1_java.cuentas;

import ar.org.centro8.java.curso.tp1_java.clientes.Cliente;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public abstract class Cuenta {
    private int nroCuenta;
    private double saldo;
    private Cliente cliente;

    /**
     * método para depositar efectivo
     * 
     * @param monto
     */
    public abstract void depositarEfectivo(double monto);

    /**
     * método para extraer efectivo *
     * 
     * @param monto
     */
    public abstract void extraerEfectivo(double monto);

}
