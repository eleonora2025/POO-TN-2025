package ar.org.centro8.java.curso.tp1_java.test;

import ar.org.centro8.java.curso.tp1_java.clientes.ClienteEmpresa;
import ar.org.centro8.java.curso.tp1_java.clientes.ClienteIndividual;
import ar.org.centro8.java.curso.tp1_java.cuentas.CajaDeAhorro;
import ar.org.centro8.java.curso.tp1_java.cuentas.Cheque;
import ar.org.centro8.java.curso.tp1_java.cuentas.CuentaConvertibilidad;
import ar.org.centro8.java.curso.tp1_java.cuentas.CuentaCorriente;

public class Test {
    public static void main(String[] args) {
        // Crear clientes
        ClienteIndividual clienteIndividual1 = new ClienteIndividual(1, "Luciana", "Perez", "20159753");
        System.out.println(clienteIndividual1);

        ClienteEmpresa clienteEmpresa1 = new ClienteEmpresa(2, "Jorgelin", "38426791");
        System.out.println(clienteEmpresa1);

        // Crear Caja de Ahorro
        CajaDeAhorro cajaDeAhorro1 = new CajaDeAhorro(1001, 5000, clienteIndividual1, 30);

        // Crear Cuenta Corriente
        CuentaCorriente cuentaCorriente1 = new CuentaCorriente(1530, 35000, clienteEmpresa1, 10000);

        // cheque
        Cheque cheque1 = new Cheque(7000, "Banco Nación", "02/09/2025");

        // Crear Cuenta Convertibilidad
        CuentaConvertibilidad cuentaConvertibilidad1 = new CuentaConvertibilidad(3, 5000, clienteEmpresa1, 0, 2000);

        // Operaciones Caja de Ahorro
        System.out.println("\n--- Operaciones Caja de Ahorro ---");
        System.out.println("\n--- Estado inicial ---");
        System.out.println(cajaDeAhorro1);
        cajaDeAhorro1.depositarEfectivo(1000);
        cajaDeAhorro1.extraerEfectivo(2000);
        cajaDeAhorro1.cobrarInteres();
        cajaDeAhorro1.extraerEfectivo(7000); // fondos insuficientes, caja de ahorro no gira descubierto

        // Operaciones Cuenta Corriente
        System.out.println("\n--- Operaciones Cuenta Corriente ---");
        System.out.println("\n--- Estado inicial ---");
        System.out.println(cuentaCorriente1);
        cuentaCorriente1.depositarEfectivo(500);
        cuentaCorriente1.extraerEfectivo(2500);
        cuentaCorriente1.extraerEfectivo(40000);// giro descubierto
        // Depositar cheque en cuenta corriente
        System.out.println("\n--- Depósito de Cheque ---");
        cuentaCorriente1.depositarCheque(cheque1); // alcanza para cubrir el descubierto
        cuentaCorriente1.extraerEfectivo(10000); // extrae el total del descubierto ($10.000)
        cuentaCorriente1.extraerEfectivo(5000); // no le queda giro descubierto

        // Operaciones Cuenta Convertibilidad
        System.out.println("\n--- Operaciones Cuenta Convertibilidad ---");
        System.out.println("\n--- Estado inicial ---");
        System.out.println(cuentaConvertibilidad1);
        cuentaConvertibilidad1.depositarEfectivo(20000);
        cuentaConvertibilidad1.extraerEfectivo(9000);
        cuentaConvertibilidad1.depositarDolares(300);
        cuentaConvertibilidad1.extraerDolares(600);
        cuentaConvertibilidad1.convertirPesosADolares(4000, 200);
        cuentaConvertibilidad1.convertirDolaresAPesos(720, 200);
        cuentaConvertibilidad1.extraerDolares(2000); // no se puede girar al descubierto en dólares

    }

}