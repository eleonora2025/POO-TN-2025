﻿package ar.org.centro8.java.curso.tp1_java.cuentas;

import ar.org.centro8.java.curso.tp1_java.clientes.Cliente;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)

public class CajaDeAhorro extends Cuenta {
    private double tasaInteres;

    public CajaDeAhorro(int nroCuenta, double saldo, Cliente cliente, double tasaInteres) {
        super(nroCuenta, saldo, cliente);
        this.tasaInteres = tasaInteres;
    }

    /**
     * método sobreescrito para depositar efectivo
     */
    @Override
    public void depositarEfectivo(double monto) {
        setSaldo(getSaldo() + monto);
        System.out.println("Depósito exitoso en Caja de Ahorro. Nuevo saldo: $" + getSaldo());
    }

    /**
     * método sobre escrito para extraer efectivo
     */

    @Override
    public void extraerEfectivo(double monto) {
        if (monto > getSaldo()) {
            System.out.println("El saldo de Caja de Ahorro es insuficiente");
        } else {
            setSaldo(getSaldo() - monto);
            System.out.println("Saldo en caja de ahorros es de $" + getSaldo());
        }
    }

    /**
     * método para cobrar interés
     */
    public void cobrarInteres() {
        double interes = getSaldo() * (tasaInteres / 100);
        setSaldo((getSaldo() + interes));
        System.out.println("Saldo en caja de ahorros con el interés es de $" + getSaldo());
    }

}
