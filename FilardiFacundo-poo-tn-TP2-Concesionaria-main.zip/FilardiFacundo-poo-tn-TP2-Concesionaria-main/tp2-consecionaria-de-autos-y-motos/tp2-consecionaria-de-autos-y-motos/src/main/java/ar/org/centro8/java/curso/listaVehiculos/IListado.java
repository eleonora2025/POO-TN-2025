package ar.org.centro8.java.curso.listaVehiculos;

import ar.org.centro8.java.curso.vehiculos.Vehiculo;

public interface IListado {
    void ordenarPorPrecioDescendente(); //ordena de mayor a menor precio
    void ordenarPorOrdenNatural();
    void agregarVehiculos(Vehiculo... v);
    void imprimirVehiculos();
    void vehiculoMasCaro();
    void vehiculoMasBarato();
    void vehiculoPorLetra(String letra);
}

