package ar.org.centro8.java.curso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp2ConsecionariaDeAutosYMotosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp2ConsecionariaDeAutosYMotosApplication.class, args);
	}

}
