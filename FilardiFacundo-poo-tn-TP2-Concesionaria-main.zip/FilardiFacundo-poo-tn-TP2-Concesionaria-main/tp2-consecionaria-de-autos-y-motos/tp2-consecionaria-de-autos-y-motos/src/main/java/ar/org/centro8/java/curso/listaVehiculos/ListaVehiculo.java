package ar.org.centro8.java.curso.listaVehiculos;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.org.centro8.java.curso.vehiculos.Vehiculo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ListaVehiculo implements IListado {
    private List<Vehiculo> vehiculos;

    public ListaVehiculo() {
        this.vehiculos = new ArrayList<>();
    }

    @Override
    public void ordenarPorPrecioDescendente() {
        System.out.println("\n=============================\n");
        System.out.println("Vehículos ordenados por precio de mayor a menor");
        vehiculos
                .stream()
                .sorted(Comparator.comparing(Vehiculo::getPrecio)
                        .reversed())
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    }

    @Override
    public void ordenarPorOrdenNatural() {
        System.out.println("\n=============================\n");
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio): ");
        vehiculos
                .stream()
                .sorted()
                .forEach(System.out::println);
    }

    @Override
    public void agregarVehiculos(Vehiculo... v) {
        for (int i = 0; i < v.length; i++) {
            vehiculos.add(v[i]);
        }
    }

    @Override
    public void imprimirVehiculos() {
        System.out.println("\n \n ");
        vehiculos.forEach(System.out::println);
    }

    @Override
    public void vehiculoMasCaro() {
        System.out.println("\n=============================\n");
        double precioMax = vehiculos
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get()
                .getPrecio();

        vehiculos
                .stream()
                .filter(v -> v.getPrecio() == precioMax)
                .forEach(v -> System.out.println("Vehículo más caro: " + v.getMarca() + " " + v.getModelo()));
    }

    @Override
    public void vehiculoMasBarato() {
        double precioMin = vehiculos
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get()
                .getPrecio();

        vehiculos
                .stream()
                .filter(v -> v.getPrecio() == precioMin)
                .forEach(v -> System.out.println("Vehículo más barato: " + v.getMarca() + " " + v.getModelo()));
    }

    // @Override
    // public void vehiculoPorLetra(String letra) {
    // vehiculos.stream()
    // .filter(v -> v.getModelo().toLowerCase().contains((letra).toLowerCase()))
    // .forEach(v -> System.out.println(
    // String.format("Vehículo que contiene en el modelo la letra 'y' ","%,.2f",
    // letra, v.getMarca(), v.getModelo(), v.getPrecio())));
    // }

    @Override
    public void vehiculoPorLetra(String letra) {
        vehiculos.stream()
                .filter(v -> v.getModelo().toLowerCase().contains(letra.toLowerCase()))
                .forEach(v -> System.out.println(
                        String.format("Vehículo que contiene en el modelo la letra '%s': %s %s $%,.2f",
                                letra, v.getMarca(), v.getModelo(), v.getPrecio())));
    }

}