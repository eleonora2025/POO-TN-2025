package ar.org.centro8.java.curso.vehiculos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor

public abstract class Vehiculo implements Comparable<Vehiculo> {
    
    private String marca;
    private String modelo;
    private double precio;

   
    @Override
    public int compareTo(Vehiculo v) {
        int comparacion = this.marca.compareToIgnoreCase(v.marca);
        if (comparacion == 0) {
            comparacion = this.modelo.compareToIgnoreCase(v.modelo);
            if (comparacion == 0) {
                return Double.compare(this.precio, v.precio);
            }
        }
        return comparacion;

    }   

}
