﻿package ar.org.centro8.java.curso.tp2.interfaces;

import ar.org.centro8.java.curso.tp2.entidades.Vehiculo;

public interface IVehiculo {
    // agregar vehículos a la lista utlizando varargs
    void agregarVehiculos(Vehiculo... v);

    // salida por consola los vehículos
    void imprimirVehiculos();

    // salida por consola el vehículo más caro
    void vehiculoMasCaro();

    // salida por consola el vehículo más barato
    void vehiculoMasBarato();

    // salida por consola el primer vehículo que contienen la letra que entra como
    // parámetro, en su modelo.
    void vehiculoPorLetra(String letra);

    // salida por consola los vehículos ordenados por precio de forma descendente
    void vehiculosPorPrecioDescendente();

    // salida por consola los vehículos ordenados de forma natural (por marca,
    // modelo y precio)
    void vehiculosPorOrdenNatural();

}
