package ar.org.centro8.java.curso.tp2.entidades;

import java.text.DecimalFormat;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class Moto extends Vehiculo {
    private int cilindrada;

    public Moto(String marca, String modelo, double precio, int cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("$#,##0.00");
        return String.format("Marca: " + getMarca() + " // Modelo: " + getModelo() + " // Cilindrada: " + cilindrada
                + "c" + "// Precio: " +
                df.format(getPrecio()));
    }

}
