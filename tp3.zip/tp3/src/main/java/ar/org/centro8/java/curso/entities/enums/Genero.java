package ar.org.centro8.java.curso.entities.enums;

public enum Genero {
    Masculino,
    Femenino;

}
