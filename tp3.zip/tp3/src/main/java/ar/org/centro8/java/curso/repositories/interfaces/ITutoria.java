package ar.org.centro8.java.curso.repositories.interfaces;

public interface ITutoria {

}
