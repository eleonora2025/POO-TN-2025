package ar.org.centro8.java.curso.entities;

import lombok.Data;

@Data
public class Empresa {
    private int id;
    private String nombre_empresa;
    private String cuit;

}
