package ar.org.centro8.java.curso.entities.enums;

public enum NombreEvaluador {
    Mazzei_María_Cecilia,
    Domínguez_Martín_Erasmo,
    Montenegro_Ramiro;

}
