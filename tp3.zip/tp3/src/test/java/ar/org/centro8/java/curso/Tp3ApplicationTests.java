package ar.org.centro8.java.curso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
